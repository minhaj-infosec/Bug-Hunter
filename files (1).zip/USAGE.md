# Bug Hunter Master Pipeline v2.0 — ব্যবহার গাইড

## 📁 ফাইল স্ট্রাকচার

```
bug_hunter_pipeline.sh   ← মূল স্ক্রিপ্ট
install_tools.sh         ← টুল ইনস্টলার
USAGE.md                 ← এই গাইড
```

---

## ⚙️ ধাপ ১ — ইনস্টলেশন

```bash
# ১. ফাইল নামাও
git clone https://github.com/your-repo/bug-hunter-pipeline
cd bug-hunter-pipeline

# ২. সব টুল একসাথে ইনস্টল করো
bash install_tools.sh

# ৩. Script কে executable বানাও
chmod +x bug_hunter_pipeline.sh

# ৪. PATH এ Go bin যোগ করো (যদি নতুন ইনস্টল করা হয়)
source ~/.bashrc
```

---

## 🚀 ধাপ ২ — রান করা

### ২.১ সবচেয়ে সহজ — শুধু domain দাও

```bash
./bug_hunter_pipeline.sh -d target.com
```

এটাই যথেষ্ট। পাঁচটা phase সব অটো চলবে।

---

### ২.২ পূর্ণ pipeline — সব feature চালু

```bash
./bug_hunter_pipeline.sh \
  -d target.com \
  -t "eyJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoidXNlcjEifQ.xxx" \
  -c "abc123.oast.fun" \
  -T "110201543:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw" \
  -C "1234567890" \
  -S "https://hooks.slack.com/services/T.../B.../xxx" \
  -x 80 \
  -r 150
```

**প্রতিটা flag এর কাজ:**

| Flag | কী দিতে হবে | কাজ |
|------|------------|-----|
| `-d` | `target.com` | **Required.** টার্গেট ডোমেইন |
| `-t` | JWT token | Authenticated IDOR/BAC testing এর জন্য |
| `-c` | `abc.oast.fun` | Blind SQLi/SSRF/Host-header OOB callback |
| `-T` | Telegram bot token | Finding পেলে Telegram notify করবে |
| `-C` | Telegram chat ID | তোমার Telegram chat এর ID |
| `-S` | Slack webhook URL | Finding পেলে Slack notify করবে |
| `-x` | সংখ্যা (default 50) | Concurrent threads |
| `-r` | সংখ্যা (default 100) | Rate limit per second |

---

### ২.৩ Mode অনুযায়ী রান

#### 🔍 শুধু Recon (দ্রুত subdomain scan)
```bash
./bug_hunter_pipeline.sh -d target.com -m recon
```

#### 🎯 শুধু Hunt (recon আগে হয়ে থাকলে)
```bash
./bug_hunter_pipeline.sh \
  -d target.com \
  -m hunt \
  -o ./hunt_target.com_20240601_120000
# -o দিয়ে আগের recon output folder দাও
```

#### 📡 শুধু Monitor setup
```bash
./bug_hunter_pipeline.sh -d target.com -m monitor
```

---

### ২.৪ Skip flags — সময় বাঁচাতে

```bash
# Monitor setup skip করো (CI/CD তে useful)
./bug_hunter_pipeline.sh -d target.com --skip-monitor

# HTML report skip করো
./bug_hunter_pipeline.sh -d target.com --skip-report

# Recon এর পর বন্ধ করো
./bug_hunter_pipeline.sh -d target.com --only-recon

# Verbose output দেখতে
./bug_hunter_pipeline.sh -d target.com -v
```

---

### ২.৫ Custom output directory

```bash
./bug_hunter_pipeline.sh -d target.com -o /home/user/hunts/target_com
```

---

## 📂 Output ফোল্ডার স্ট্রাকচার

```
hunt_target.com_20240601_120000/
│
├── 01_recon/
│   ├── all_subs.txt              ← সব unique subdomains
│   ├── subs/
│   │   ├── subfinder.txt
│   │   ├── assetfinder.txt
│   │   ├── crtsh.txt
│   │   └── wayback_subs.txt
│   ├── live/
│   │   ├── live_hosts.txt        ← httpx output (status+title+tech)
│   │   └── scored_targets.txt    ← score অনুযায়ী সর্টেড
│   ├── cloud/
│   │   ├── s3.txt
│   │   ├── azure.txt
│   │   └── gcp.txt
│   ├── certs/
│   │   └── ssl_info.txt
│   └── ports/
│       └── nmap_results.txt
│
├── 02_js_hunter/
│   ├── files/
│   │   └── all_js.txt            ← সব JS file URL
│   ├── secrets/
│   │   └── raw_secrets.txt       ← ⚠️ পাওয়া সব secrets
│   ├── endpoints/
│   │   ├── rest_api.txt          ← JS থেকে পাওয়া API endpoints
│   │   ├── graphql_ops.txt
│   │   └── hardcoded_urls.txt
│   └── sourcemaps/
│       ├── found.txt             ← exposed .map files
│       └── original_sources.txt
│
├── 03_param_hunter/
│   ├── urls/
│   │   ├── all_params.txt        ← সব parameterized URL
│   │   ├── xss_candidates.txt
│   │   ├── sqli_candidates.txt
│   │   └── redirect_candidates.txt
│   ├── xss/
│   │   ├── reflected.txt
│   │   └── confirmed.txt         ← ✅ confirmed XSS
│   ├── sqli/
│   │   ├── error_based.txt       ← ✅ confirmed SQLi
│   │   └── potential_blind.txt
│   ├── ssti/
│   │   └── confirmed.txt         ← ✅ confirmed SSTI
│   ├── redirect/
│   │   └── confirmed.txt
│   └── other/
│       └── crlf.txt
│
├── 04_bac_finder/
│   ├── idor/
│   │   └── numeric.txt           ← IDOR hits
│   ├── methods/
│   │   └── bypass.txt            ← method switching results
│   ├── 403bypass/
│   │   └── found.txt             ← header/path bypass
│   ├── cors/
│   │   └── misconfig.txt         ← CORS issues
│   ├── jwt/
│   │   └── results.txt           ← JWT attack results
│   └── graphql/
│       ├── findings.txt
│       └── schema.txt
│
├── pipeline.log                  ← সব execution log
├── stats.env                     ← numeric findings summary
└── report_target.com_TIMESTAMP.html  ← 🌐 HTML report
```

---

## 📊 Output পড়ার নিয়ম

### সবচেয়ে গুরুত্বপূর্ণ ফাইলগুলো আগে দেখো:

```bash
# ১. Critical findings (secrets)
cat hunt_*/02_js_hunter/secrets/raw_secrets.txt

# ২. Top juicy targets
head -20 hunt_*/01_recon/live/scored_targets.txt

# ৩. SQLi confirmed
cat hunt_*/03_param_hunter/sqli/error_based.txt

# ৪. IDOR findings
cat hunt_*/04_bac_finder/idor/numeric.txt

# ৫. HTML report browser এ খোলো
firefox hunt_*/report_*.html
# অথবা
xdg-open hunt_*/report_*.html
```

---

## 📡 Telegram Bot Setup (Notification এর জন্য)

```
১. Telegram এ @BotFather কে /newbot বলো
২. Bot name দাও → token পাবে (এটাই -T flag এ দেবে)
৩. তোমার chat ID পেতে:
   https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates
   → "chat":{"id":XXXXXXX}  ← এটাই -C flag এ দেবে
```

---

## 🔧 Interactsh OOB Server Setup (-c flag)

```bash
# Option 1: interactsh-client দিয়ে নিজেই চালাও
interactsh-client
# দেবে: abc123.oast.fun → এটা -c তে দাও

# Option 2: Burp Collaborator
# Burp Suite Pro → Collaborator → Copy to clipboard
```

---

## 💡 Real-World Workflow (Professional)

### Scenario 1: নতুন private program পেলে

```bash
# Step 1: দ্রুত recon
./bug_hunter_pipeline.sh -d target.com -m recon -x 100

# Step 2: juicy targets দেখো
head -30 hunt_target.com_*/01_recon/live/scored_targets.txt

# Step 3: full hunt চালাও
./bug_hunter_pipeline.sh \
  -d target.com \
  -m hunt \
  -t "YOUR_JWT" \
  -c "YOUR_COLLAB" \
  -o hunt_target.com_*/   # আগের recon output reuse
```

### Scenario 2: Monitor + First Blood

```bash
# একবার setup করো — ঘুমের মধ্যেও কাজ করবে
./bug_hunter_pipeline.sh \
  -d target.com \
  -m monitor \
  -T "BOT_TOKEN" \
  -C "CHAT_ID"

# নতুন subdomain live হলে Telegram এ alert আসবে
# সকালে উঠে → নতুন target → সবার আগে hunt করো → first blood 🩸
```

### Scenario 3: Program এ নতুন scope added

```bash
# Incremental — শুধু নতুন scope hunt করো
./bug_hunter_pipeline.sh \
  -d newscope.target.com \
  -t "YOUR_JWT" \
  --skip-monitor \
  -x 100 -r 200
```

---

## ⚠️ Legal & Ethical Rules

```
✅ শুধুমাত্র authorized scope এ রান করো
✅ Bug bounty program এর rules পড়ো আগে
✅ Private program এ aggressive scanning করো না
✅ Responsible disclosure করো সবসময়
✅ Rate limit মেনে চলো (-r flag)
❌ Unauthorized target এ রান করা ILLEGAL
```

---

## 🐛 Troubleshooting

| সমস্যা | সমাধান |
|--------|--------|
| `command not found: subfinder` | `bash install_tools.sh` রান করো |
| Go tools path নেই | `source ~/.bashrc` বা `export PATH=$PATH:$HOME/go/bin` |
| Permission denied | `chmod +x bug_hunter_pipeline.sh` |
| Rate limit ban | `-r 30 -x 20` দিয়ে কমাও |
| Empty output | Target টা in-scope কিনা চেক করো |
| cron কাজ করছে না | `crontab -l` দিয়ে verify করো |

---

*Bug Hunter Master Pipeline v2.0 — Authorized use only*
